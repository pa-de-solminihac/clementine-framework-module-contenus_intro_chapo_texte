--
-- Table structure for table `clementine_cms_contenu_html_intro_chapo_texte`
--

DROP TABLE IF EXISTS `clementine_cms_contenu_html_intro_chapo_texte`;
CREATE TABLE `clementine_cms_contenu_html_intro_chapo_texte` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `contenu_html` text NOT NULL,
  `contenu_html_chapo` text NOT NULL,
  `contenu_html_intro_chapo_texte` text NOT NULL,
  `lang` char(2) NOT NULL DEFAULT 'fr',
  PRIMARY KEY (`id`,`lang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
